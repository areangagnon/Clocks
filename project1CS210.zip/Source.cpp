#include <iostream>

using namespace std;


void AddHour(int& hour, int& minute, int& second) { // addHour function allows user to add an hour from menu
    hour = (hour + 1) % 24;
}

void AddMinute(int& hour, int& minute, int& second) { // addMinute function allows user to add a minute
    minute = minute + 1;
    if (minute >= 60) {
        minute = 0;
        AddHour(hour, minute, second);
    }
}


void AddSecond(int& hour, int& minute, int& second) { // addSecond allows user to add a second
       second = second + 1; // add second
    if (second >= 60) { // check to make sure its not going over a minute, and if so adds a minute
       second = 0;
       AddMinute(hour, minute, second);
        }
    }


void displayTime(int hour, int minute, int second) { // allows for clock to be called and displayed
    cout << "***********************" << endl;
    cout << "*" << "24-Hour Clock: " << (hour < 10 ? "0" : "") << hour << ":" << (minute < 10 ? "0" : "") << minute << ":" << (second < 10 ? "0" : "") << second << "*" << endl;  // 24-hour clock
    // conditional expression check to see if something is true such as the hour or minute being below 10 would have to add a 0 in front
    cout << "***********************" << endl;

    string am_pm = hour < 12 ? "am" : "pm"; // checks for am or pm
    hour = hour % 12;
    if (hour == 0) hour = 12;

    // Display 12-hour format
    cout << "**********************" << endl;
    cout << "*" << "12-Hour Clock: " << (hour < 10 ? "0" : "") << hour << ":" << (minute < 10 ? "0" : "") << minute << ":" << (second < 10 ? "0" : "") << second << " " << am_pm << "*" << endl;
    cout << "**********************" << endl;

}

    int main() {
        int hour;
        int minute; 
        int second; 
        int choice;

        // user enters the current time
        cout << "Enter the current time (HH MM SS): ";
        cin >> hour >> minute >> second;

        do { // do while loop for menu to pop up as long as user doesn't enter 4

            displayTime(hour, minute, second); // shows current time


            cout << "\nMenu:\n1. Add Hour\n2. Add Minute\n3. Add Second\n4. Exit\nEnter your choice: "; // display menu 
            cin >> choice;

            switch (choice) { // switch is a good option for this scenario as it allows the 1-4 option easily
            case 1: AddHour(hour, minute, second); break;
            case 2: AddMinute(hour, minute, second); break;
            case 3: AddSecond(hour, minute, second); break;
            case 4: cout << "Exiting program." << endl; break;
            }

        } while (choice != 4);
        
    return 0;
   }

